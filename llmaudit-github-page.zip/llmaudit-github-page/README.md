# LLM Audit landing page concept

This is a static, responsive HTML landing-page concept inspired by the public LLM Audit homepage. Buttons link to the official LLM Audit site and signup flow.

## Preview locally
Open `index.html` in a browser.

## Publish with GitHub Pages
1. Create a new GitHub repository (for example, `llmaudit-page`).
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then save.
6. Wait for GitHub Pages to publish and use the provided URL.

## Important
This is a static recreation/campaign concept, not the official LLM Audit website. Get company approval before publishing it under the LLM Audit name/branding. The dashboard visuals are illustrative mockups, not live product data. All primary CTA buttons route to `https://www.llmaudit.ai/signup`; the homepage links route to `https://www.llmaudit.ai/`.
